-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mar 18, 2024 alle 09:09
-- Versione del server: 10.4.21-MariaDB
-- Versione PHP: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `verifica_sess_cookie`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `utente`
--

CREATE TABLE `utente` (
  `username` varchar(250) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `utente`
--

INSERT INTO `utente` (`username`, `password`) VALUES
('', '$2y$10$m0DZ7OLprvNzcttrBJEhYOMoEa/FDxos36lNUl6hsrANay9tlFrV6'),
('a', '$2y$10$RLvjStlqqRLviMesqn2Ue.BFh/PY9YBwmz.eNw3x6qmLKbauy7Q52'),
('b', '$2y$10$qfvBDAcTBLWck8vHk1jL8eIisjWiRm1pp0X6mBTu7BJXALbN2cplW'),
('c', '$2y$10$LZFyU7SzXp0iZGqjQFGj1uO7IPC9fYUK4zP4./OSxcdl2/2VzPd6W'),
('test', '$2y$10$LeHU9SrlLTddbVgb5m6XE.GrkpMNWG8lis996/STUc39jnqND/nPW');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `utente`
--
ALTER TABLE `utente`
  ADD PRIMARY KEY (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
